package Minesweeper;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Random;

import javax.swing.*;

public class TheMine extends JFrame {
	private final int hGap = 5;
	private final int vGap = 5;
	private JButton buttonclicked;
	//private JButton squares[][];
	private JButton[] gridButtons = new JButton[10 * 10];
	 static String easyString = "Easy";
	    static String mediumString = "Medium";
	    static String hardString = "Hard";

	private ActionListener buttonClickListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			//Icon pressedIcon = new ImageIcon(					"src/images/clock.png");
			//buttonclicked.setPressedIcon(pressedIcon);
			Random generator = new Random();
			int num1 = generator.nextInt(5); 
			if( e.getSource() instanceof JButton) {
				  
			       ((JButton)e.getSource()).setBackground(Color.LIGHT_GRAY);
			     
			       if(num1==4){
			    	   ((JButton)e.getSource()).setText(String.format("*"));
			    	   ((JButton)e.getSource()).setBackground(Color.RED);
			    	    GameLost();
			    	   ((JButton)e.getSource()).setEnabled(false);
			    	    
			       }else {
			    	   ((JButton)e.getSource()).setText(String.format(""+num1));
			    	   ((JButton)e.getSource()).setEnabled(false);
			    	    
			       }
			   }
			
		}
	};
	
	private ActionListener NewGameListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if( e.getSource() instanceof JButton) {  
			 
				NewGame();
		      
		
			}
			
		}
	};
	
	public  Component LevelRadio (){
		 //Create the radio buttons.
        JRadioButton EasyButton = new JRadioButton(easyString);
        EasyButton.setMnemonic(KeyEvent.VK_B);
        EasyButton.setActionCommand(easyString);
        EasyButton.setSelected(true);

        JRadioButton MediumButton = new JRadioButton(mediumString);
        MediumButton.setMnemonic(KeyEvent.VK_C);
        MediumButton.setActionCommand(mediumString);

        JRadioButton HardButton = new JRadioButton(hardString);
        HardButton.setMnemonic(KeyEvent.VK_D);
        HardButton.setActionCommand(hardString);
      //Group the radio buttons.
        ButtonGroup group = new ButtonGroup();
        group.add(EasyButton);
        group.add(MediumButton);
        group.add(HardButton);

     
        //Register a listener for the radio buttons.
      //  EasyButton.addActionListener(this);
      //  MediumButton.addActionListener(this);
      //  HardButton.addActionListener(this);
        //Put the radio buttons in a column in a panel.
        JPanel radioPanel = new JPanel(new GridLayout(0, 1));
        radioPanel.add(EasyButton);
        radioPanel.add(MediumButton);
        radioPanel.add(HardButton);
   

        add(radioPanel, BorderLayout.LINE_START);
		return radioPanel;
     
	
	}

	public void NewGame () {
		for (int i=0;i<100;i++){
			gridButtons[i].setBackground(null);
			gridButtons[i].setText(String.format(""));
			gridButtons[i].setEnabled(true);
		}
	}
	
	public void GameLost(){
	
		JOptionPane.showMessageDialog(new JFrame(), "I am sorry, you lost! Click New Game to play again or Help to learn more about Minesweeper.");

	}
	
	// OpenPage method to open urls on the user default browser
	public void openWebPage(String url){
		   try {         
		     java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
		   }
		   catch (java.io.IOException e) {
		       System.out.println(e.getMessage());
		   }
		}
	
	// Help Button listener, it will temporarily direct the user to online documentation
	private ActionListener HelpButtonListener = new ActionListener() 
	{
	    public void actionPerformed(ActionEvent e)
	    {
	        openWebPage("http://www.minesweeper.info/wiki/Windows_Minesweeper");
	    }
	};
	
	
	public void init() {

		Container mainpane = getContentPane();
		

		JButton NewGameButton = new JButton("New Game");
		NewGameButton.addActionListener(NewGameListener);
		JButton LogGameButton = new JButton ("Log Game");
		//LogGameButton.addActionListener(LogListener);
		JButton HelpButton = new JButton("Help");
		HelpButton.addActionListener(HelpButtonListener);
		// Labels creation
		//---------------------------------Icons--------------------------//
		ImageIcon icon = new ImageIcon(
				"src/images/walker.png");
		ImageIcon iconLevel = new ImageIcon("src/images/level.png");
		ImageIcon iconCellsOpened = new ImageIcon(
				"src/images/open.png");
		ImageIcon iconTimeSpend = new ImageIcon(
				"src/images/clock.png");
		// labels
		JLabel image1L = new JLabel(icon, JLabel.CENTER);
		JLabel level = new JLabel("Level", iconLevel, JLabel.CENTER);
		JLabel boxesLeft = new JLabel("Cells Opened", iconCellsOpened, JLabel.CENTER);
		JLabel time = new JLabel("Time Spend", iconTimeSpend, JLabel.CENTER);
// -----------------------------------------Panel setup------------------------------------- // 
		// Left Panel buttons
		JPanel panelL = new JPanel();
		panelL.setLayout(new GridLayout(10, 10));
			
		for (int i = 0; i < gridButtons.length; i++) {			
			gridButtons[i]= new JButton("");

		}
		
		for (int i=0;i<100;i++){
			panelL.add(gridButtons[i]);
			gridButtons[i].addActionListener(buttonClickListener);
		}
		
		JPanel panelLeft = new JPanel();
		panelLeft.setLayout(new BoxLayout(panelLeft, BoxLayout.Y_AXIS));
		panelLeft.add(panelL);
		panelLeft.setBorder(BorderFactory.createTitledBorder("Play"));
		
		
		//panelL.add(buttonclicked);

		// Right Panel box 1 that includes the label, image, and first three X
		// Axis buttons

		JPanel panelR1 = new JPanel();
		panelR1.setSize(20, 20);
		panelR1.setLayout(new BoxLayout(panelR1, BoxLayout.Y_AXIS));
		panelR1.setBorder(BorderFactory.createTitledBorder("The Mine"));
		panelR1.add(image1L, BorderLayout.PAGE_START);
		

		JPanel panelR2 = new JPanel();
		panelR2.setLayout(new BoxLayout(panelR2, BoxLayout.X_AXIS));
		panelR2.add(level);
		panelR2.add(LevelRadio());
		panelR2.add(new JSeparator(SwingConstants.VERTICAL) );
		panelR2.add(boxesLeft);
		panelR2.add(new JSeparator(SwingConstants.VERTICAL) );
		panelR2.add(time);		
		panelR2.setBorder(BorderFactory.createTitledBorder("Your status"));
		

		// Right Panel box 2 that includes all settings buttons
		JPanel panelR3 = new JPanel();
		panelR3.setLayout(new FlowLayout());
		panelR3.add(NewGameButton);
		panelR3.add(LogGameButton);
		panelR3.add(HelpButton);
		panelR3.setBorder(BorderFactory.createTitledBorder("Settings"));
		panelR3.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);

		// final Right Panel
		JPanel panelR = new JPanel();
		panelR.setLayout(new BorderLayout());
		panelR.add(panelR1, BorderLayout.NORTH);
		panelR.add(Box.createRigidArea(new Dimension(10, 0)));
		panelR.add(panelR2, BorderLayout.CENTER);
		panelR.add(panelR3, BorderLayout.SOUTH);
		
		//panelR.setSize(new Dimension(200,400));

		mainpane.setLayout(new BorderLayout());
		mainpane.add(panelLeft, BorderLayout.WEST);
		mainpane.add(panelR, BorderLayout.CENTER);
		mainpane.setPreferredSize(getPreferredSize());

	}

	public static void main(String[] args) {
		TheMine themine = new TheMine();
		themine.init();
		themine.setResizable(true);
		themine.pack();
		//themine.setSize(700,400);
		themine.setVisible(true);
		themine.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
