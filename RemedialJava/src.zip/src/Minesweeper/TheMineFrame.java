package Minesweeper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TheMineFrame extends JPanel 
{
    private final int ROWS = 10;
    private final int COLUMNS = 10;
    private int numOfMines;
    private double probability;
    private JLabel statusBar;
    private int minesLeft;
    private JButton Minefield[][];
    private boolean hasMine = false;
    private int curRow = 0;
    private int curCol = 0;
    private JButton cell;

    public TheMineFrame() 
    {
        setLayout(new GridLayout(10, 10));
        Minefield = new JButton[ROWS][COLUMNS];
        //menuStuff();
        buildButtonField();
    }

    //I will eventually want to create a menu, but it's extra credit so I'm going to
    //wait until I have a working program.
    public JMenuBar menuStuff()
    {
        JMenuBar menuBar = new JMenuBar();
        //add(menuBar);
        JMenu file = new JMenu("File");
        menuBar.add(file);
        JMenu edit = new JMenu("Edit");
        menuBar.add(edit);
        return menuBar;
    }

    //Adds one to the total number of mines.
    public void addMine()
    {
        numOfMines++;
    }

    //Removes one from the total number of mines.
    public void removeMine()
    {
        numOfMines--;
    }

    //Assigns a JButton the value of true or false, which represents whether or not it
    //it is a mine. Is this the correct way to do this?
    public boolean setMines(JButton button)
    {
        probability  = Math.random()*100;
        if(probability >= 80)
        {
            hasMine = true;
            addMine();
        }
        else
        {
            hasMine = false;
        }
        return hasMine;
    }

    //This is supposed to change the JButton that is clicked on to either a T
    //or an F, eventually this will reveal what the value of the button is
    //or place a flag down. I'm guessing I shouldn't have used a for loop, but I don't 
    //know how else to do it.
    private class MouseHandler extends MouseAdapter
    {
        public void mouseClicked(MouseEvent e)
        {
            for(int r=0; r<ROWS; r++)
            {
                for(int c=0; c<COLUMNS; c++)
                {
                    if(e.getButton() == 1)
                    {
                        Minefield[r][c].setText("T");
                    }
                    else if(e.getButton() == 3)
                    {
                        Minefield[r][c].setText("F");
                    }
                }
            }
        }
    }

    //This builds the "Minefield" with a ROWS*COLUMNS amount of buttons.
    //It works fine but I'm open to suggestions on a better way to do this.
    public void buildButtonField()
    {
        for(int r = 0; r < ROWS; r++)
        {
            curRow++;
            for(int c = 0; c < COLUMNS; c++)
            {
                Minefield[r][c] = new JButton((r+1) + ", " + (c+1));

                setMines(Minefield[r][c]);

                Minefield[r][c].addMouseListener(new MouseHandler());

                add(Minefield[r][c]);
                curCol++;
            }
        }
    }
}