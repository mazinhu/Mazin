package Minesweeper;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
public class TESTing {
  public static void main(final String args[]) {
    JButton button = new JButton();
    Icon pressedIcon = new ImageIcon("walker.png");
    button.setPressedIcon(pressedIcon);

    JOptionPane.showMessageDialog(null, button);
  }
}
