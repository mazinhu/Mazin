package session1.introduction;

public class HelloWorld {
	
	public static void main (String[] arguments) {
		System.out.println("Hello World !");

		String cat = "Garfield";
		int age = 3;

		System.out.println("My cat is "+ cat + " and he is " + age);
		}
}
